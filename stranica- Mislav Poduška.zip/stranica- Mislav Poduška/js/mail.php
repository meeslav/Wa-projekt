<?php
echo 'name:'; print_r($_POST['name']);
echo '</br>';
echo 'email:'; print_r($_POST['email']);
echo '</br>';
echo 'spol:'; print_r($_POST['spol']);
echo '</br>';
echo 'razlog:'; foreach($_POST['razlog'] as $value) {
  print $value;
  print ' , ';
}
echo '</br>';
echo 'message:'; print_r($_POST['message']);

		
?>